<?php 
    public function ajax(){
        $where['title'] = $this->input->post('key');
        $result = $this->action->read('test', $where);
        echo json_encode($result[0]);
    }
 ?>
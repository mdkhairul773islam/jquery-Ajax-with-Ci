<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Ajax Example with Ci</title>
	<link rel="stylesheet" href="">
</head>
<body>
	
	<div class="panel panel-default" ng-controller="companyCtrl">
	<div class="panel-heading panal-header">
		<div class="panal-header-title">
			<h1>Comapny</h1>
		</div>
	</div>
	<div class="panel-body" ng-cloak>
		<?php 
		    echo form_open_multipart('', array('class' => 'form-horizontal'));
		    echo $confirmation;
		    ?>
			<div class="form-group">
				<label class="col-md-2 text-center control-label">Title <span class="req">*</span></label>
				<div class="col-md-5">
				    <!--<select class="form-control" ng-model="titleName" ng-change="getContent()" ng-init="titleName='about_us'" name="title" required> -->
				    <select class="form-control" name="title" required> 
				        <option value="about_us">About Us </option>
				        <option value="our_key_principals">Our Key Principals</option>
				        <option value="factory">Factory</option>
				        <option value="procurement_and_export">Procurement & Export</option>
				        <option value="brand">Brand</option>
				    </select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-2 text-center control-label">Content <span class="req">*</span></label>
				<div class="col-md-8">
					<textarea name="content" id="content" cols="30" rows="10" class="form-control" required></textarea>
				</div>
			</div>
			<div class="form-group">

				<div class="col-md-2">
                    
				</div>
				<div class="col-md-8"><img width="100" ng-src="<?php echo site_url(); ?>{{path}}" /></div>
			</div>
			<div class="form-group">
				<label class="col-md-2 text-center control-label">Image </label>
				<div class="col-md-8">

					<input type="file" name="attachFile" class="form-control file">
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-2 text-center control-label"> </label>
				<div class="col-md-8">
					<input type="submit" name="save" class="btn btn-primary pull-right" >
				</div>
			</div>
		<?php echo form_close(); ?>		
	</div>
	<div class="panel-footer">
		&nbsp;
	</div>
</div>

	<script type="text/javascript">
		    $(document).ready(function(){

		        $('select').on('change', function() {
		            $.ajax({
		            url: '<?php echo site_url('about/about/ajax'); ?>',
		            type: 'POST',
		            data: {
		                key: this.value
		            },
		            dataType: 'json',
		            success: function(data) {
		                $("#content").val(data.content);
		            }
		            });
		        });
		    });

	</script>
</body>
</html>